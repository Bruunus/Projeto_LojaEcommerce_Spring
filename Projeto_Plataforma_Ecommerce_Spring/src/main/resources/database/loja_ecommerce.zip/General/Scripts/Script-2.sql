create table users(
    username varchar(200) not null primary key,
    password_ varchar(500) not null,
    enabled boolean not null
);

create table authorities(
    username varchar(100) not null,
    authority varchar(50) not null,
    constraint fk_authorities_users foreign key(username) references users(username)
);
create unique index ix_auth_username on authorities (username,authority);



describe users;
describe pedido;
select * from users;
select * from pedido;

--  Auto-generated SQL script #202203291657
DELETE FROM loja_ecommerce.users
	WHERE username='brunus';
